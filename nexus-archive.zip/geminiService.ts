
import { GoogleGenAI, Type } from "@google/genai";
import { MediaItem, SpeakerTurn } from "./types";

const RETRY_COUNT = 2;
const RETRY_DELAY = 2000;

async function withRetry<T>(fn: () => Promise<T>, retries = RETRY_COUNT): Promise<T> {
  try {
    return await fn();
  } catch (error: any) {
    const is429 = JSON.stringify(error).includes('429');
    if (retries > 0 && is429) {
      await new Promise(resolve => setTimeout(resolve, RETRY_DELAY * 2));
      return withRetry(fn, retries - 1);
    }
    throw error;
  }
}

export const geminiService = {
  // Теперь принимает ТЕКСТ, а не медиа
  async enrichTranscript(text: string): Promise<{ aiSummary: string, tags: string[], refinedTurns?: SpeakerTurn[] }> {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    return withRetry(async () => {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: [{ 
          parts: [{ 
            text: `ANALYZE THE FOLLOWING TRANSCRIPT:
            "${text}"
            
            TASKS:
            1. Create a deep semantic summary (max 3 sentences).
            2. Extract 3-5 relevant hashtags.
            3. If the text looks like a dialogue but speakers are generic, try to identify them.
            
            RETURN JSON ONLY.` 
          }] 
        }],
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              aiSummary: { type: Type.STRING },
              tags: { type: Type.ARRAY, items: { type: Type.STRING } },
              refinedTurns: { 
                type: Type.ARRAY, 
                items: { 
                  type: Type.OBJECT, 
                  properties: { 
                    speaker: { type: Type.STRING }, 
                    text: { type: Type.STRING } 
                  } 
                } 
              }
            },
            required: ["aiSummary", "tags"]
          }
        }
      });

      const resText = response.text || "{}";
      return JSON.parse(resText);
    });
  },

  async askNexus(query: string, context: MediaItem[]): Promise<{ text: string }> {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const simplifiedContext = context.slice(0, 5).map(m => `Source: ${m.title}\nSummary: ${m.aiSummary}\nText: ${m.rawText?.substring(0, 300)}`).join('\n---\n');

    return withRetry(async () => {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: [{ 
          parts: [{ 
            text: `CONTEXT FROM ARCHIVE:\n${simplifiedContext}\n\nUSER QUESTION: ${query}` 
          }] 
        }],
        config: { 
          systemInstruction: "You are Nexus AI. Use the provided archive context to answer accurately. If information is missing, use Google Search.",
          tools: [{ googleSearch: {} }]
        }
      });
      return { text: response.text || "I'm sorry, I couldn't process that request." };
    });
  }
};
