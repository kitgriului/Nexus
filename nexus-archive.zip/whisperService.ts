
const WHISPER_API_KEY = "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";

export const whisperService = {
  async transcribe(blob: Blob): Promise<string> {
    const formData = new FormData();
    // Конвертируем blob в файл для OpenAI API
    const file = new File([blob], "recording.webm", { type: blob.type });
    formData.append("file", file);
    formData.append("model", "whisper-1");
    // Можно добавить prompt для улучшения контекста (например, указать язык)
    // formData.append("language", "ru"); 

    try {
      const response = await fetch("https://api.openai.com/v1/audio/transcriptions", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${WHISPER_API_KEY}`
        },
        body: formData
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error?.message || "Whisper API error");
      }

      const data = await response.json();
      return data.text;
    } catch (e: any) {
      console.error("Whisper Error:", e);
      throw new Error(`Whisper Transcription failed: ${e.message}`);
    }
  }
};
