
import React, { useState, useEffect, useRef } from 'react';
import { db } from './db';
import { MediaItem, ChatMessage, SourceType } from './types';
import { Icon } from './components/Icons';
import { FeedItem } from './components/FeedItem';
import { geminiService } from './geminiService';
import { transcriptionService } from './transcriptionService';

const App: React.FC = () => {
  const [activeSection, setActiveSection] = useState<'ALL' | 'AUDIO' | 'LINK' | 'CHAT'>('ALL');
  const [media, setMedia] = useState<MediaItem[]>([]);
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([]);
  const [chatInput, setChatInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [processingStatus, setProcessingStatus] = useState<string | null>(null);
  const [selectedItemId, setSelectedItemId] = useState<string | null>(null);
  const [selectedTag, setSelectedTag] = useState<string | null>(null);

  const mediaRecorder = useRef<MediaRecorder | null>(null);
  const audioChunks = useRef<Blob[]>([]);

  const loadData = async () => {
    const items = await db.getMedia();
    setMedia(items);
    setChatHistory(db.getChatHistory());
    setTimeout(() => (window as any).lucide?.createIcons(), 0);
  };

  useEffect(() => { loadData(); }, []);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream, { mimeType: 'audio/webm' });
      mediaRecorder.current = recorder;
      audioChunks.current = [];
      recorder.ondataavailable = (e) => { if (e.data.size > 0) audioChunks.current.push(e.data); };
      recorder.onstop = () => {
        const blob = new Blob(audioChunks.current, { type: 'audio/webm' });
        processMaterial(blob, 'mic_audio');
        stream.getTracks().forEach(t => t.stop());
      };
      recorder.start();
      setIsRecording(true);
    } catch (e) { 
      alert("Error: Microphone access denied."); 
    }
  };

  const stopRecording = () => {
    mediaRecorder.current?.stop();
    setIsRecording(false);
  };

  // ЧЕСТНЫЙ ПАЙПЛАЙН (СЦЕНАРИЙ B)
  const processMaterial = async (data: Blob | string, sourceType: SourceType) => {
    const tempId = crypto.randomUUID();
    setProcessingStatus("Step 1: Preparing storage...");
    
    const newItem: MediaItem = {
      id: tempId,
      title: sourceType === 'youtube_url' ? 'URL Processing...' : 'Audio Record',
      type: sourceType === 'youtube_url' ? 'youtube' : 'audio',
      sourceType,
      transcriptSource: 'none',
      sourceUrl: typeof data === 'string' ? data : '',
      duration: 0,
      createdAt: Date.now(),
      importedAt: Date.now(),
      status: 'processing',
      origin: 'manual',
      tags: []
    };
    
    await db.saveMediaItem(newItem);
    await loadData();

    try {
      // ШАГ 4: Whisper Transcription
      setProcessingStatus("Step 2: Whisper STT (Real transcription)...");
      let rawText = "";
      let turns = [];

      if (typeof data !== 'string') {
        const res = await transcriptionService.processAudio(data);
        rawText = res.text;
        turns = res.turns;
      } else {
        // Попытка вызвать экстрактор (честно упадет, если нет прокси)
        const res = await transcriptionService.processUrl(data);
        rawText = res.text;
        newItem.title = res.title;
      }

      // Сохраняем промежуточный результат (уже имеем текст)
      await db.saveMediaItem({ ...newItem, rawText, transcription: turns, transcriptSource: 'whisper' });
      await loadData();

      // ШАГ 6: LLM Post-processing (Gemini)
      setProcessingStatus("Step 3: Gemini Analysis (Summary & Tags)...");
      const aiResult = await geminiService.enrichTranscript(rawText);
      
      const finalItem: MediaItem = {
        ...newItem,
        rawText,
        transcription: turns,
        transcriptSource: 'whisper',
        aiSummary: aiResult.aiSummary,
        tags: aiResult.tags,
        status: 'completed'
      };
      await db.saveMediaItem(finalItem);
      
    } catch (err: any) {
      console.error("Pipeline Failure:", err);
      const errorItem: MediaItem = { 
        ...newItem, 
        status: 'error', 
        aiSummary: `Error at ${processingStatus}: ${err.message}` 
      };
      await db.saveMediaItem(errorItem);
    } finally {
      setProcessingStatus(null);
      await loadData();
    }
  };

  const handleChat = async () => {
    if (!chatInput.trim()) return;
    const userMsg: ChatMessage = { id: crypto.randomUUID(), role: 'user', text: chatInput, timestamp: Date.now() };
    setChatHistory(prev => [...prev, userMsg]);
    setChatInput("");
    setIsTyping(true);

    try {
      const response = await geminiService.askNexus(chatInput, media);
      const aiMsg: ChatMessage = { id: crypto.randomUUID(), role: 'assistant', text: response.text, timestamp: Date.now() };
      setChatHistory(prev => {
        const h = [...prev, aiMsg];
        db.saveChatHistory(h);
        return h;
      });
    } catch (e) { console.error(e); } finally { setIsTyping(false); }
  };

  return (
    <div className="max-w-md mx-auto h-screen bg-[#fafafa] flex flex-col relative overflow-hidden shadow-2xl">
      <header className="pt-10 px-6 pb-4 bg-white/80 backdrop-blur-xl sticky top-0 z-40 border-b border-gray-100">
        <div className="flex justify-between items-center mb-6">
          <div className="flex flex-col">
            <h1 className="text-3xl font-black tracking-tighter text-black leading-none">NEXUS</h1>
            <span className="text-[9px] font-bold text-gray-400 uppercase tracking-widest mt-1">
              {processingStatus ? `● ${processingStatus}` : 'Whisper + Gemini Active'}
            </span>
          </div>
        </div>
        <div className="flex gap-2 overflow-x-auto pb-2 no-scrollbar">
          {['ALL', 'AUDIO', 'LINK', 'CHAT'].map(sec => (
            <button key={sec} onClick={() => setActiveSection(sec as any)} className={`px-4 py-2 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${activeSection === sec ? 'bg-black text-white shadow-lg' : 'bg-white text-gray-400 border border-gray-100'}`}>
              {sec}
            </button>
          ))}
        </div>
      </header>

      <main className="flex-1 overflow-y-auto px-6 pt-6 pb-48 custom-scrollbar">
        {activeSection === 'CHAT' ? (
          <div className="space-y-6 pt-2 pb-10">
             {chatHistory.map(msg => (
               <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                 <div className={`max-w-[90%] p-5 rounded-[2rem] text-sm leading-relaxed shadow-sm ${msg.role === 'user' ? 'bg-black text-white rounded-tr-none' : 'bg-white border border-gray-100 text-gray-800 rounded-tl-none'}`}>
                   {msg.text}
                 </div>
               </div>
             ))}
             {isTyping && <div className="text-[9px] font-black uppercase text-purple-400 animate-pulse pl-4 pl-4">Nexus thinking...</div>}
          </div>
        ) : (
          <div className="space-y-4">
            {processingStatus && (
              <div className="p-6 bg-black text-white rounded-[2.5rem] flex items-center gap-4 animate-pulse">
                <Icon name="loader-2" className="animate-spin text-purple-400" />
                <div className="text-xs font-bold">{processingStatus}</div>
              </div>
            )}
            {media.filter(m => !selectedTag || m.tags.includes(selectedTag)).map(item => (
              <FeedItem key={item.id} item={item} onClick={setSelectedItemId} onTagClick={setSelectedTag} />
            ))}
          </div>
        )}
      </main>

      <div className="absolute bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-[#fafafa] via-[#fafafa] to-transparent">
        <div className="bg-white border border-gray-100 rounded-[2.5rem] p-2 shadow-2xl flex items-center gap-2">
            <button 
              onClick={isRecording ? stopRecording : startRecording} 
              className={`w-14 h-14 rounded-full flex items-center justify-center transition-all ${isRecording ? 'bg-red-500 text-white animate-pulse' : 'bg-gray-50 text-gray-400 hover:bg-gray-100'}`}
            >
              <Icon name={isRecording ? 'square' : 'mic'} size={24} />
            </button>
            <input 
              type="text" 
              value={chatInput}
              onChange={e => setChatInput(e.target.value)}
              onKeyDown={e => {
                if(e.key === 'Enter') {
                  if(chatInput.includes('http')) processMaterial(chatInput, 'youtube_url');
                  else handleChat();
                }
              }}
              placeholder="Record audio or enter URL..."
              className="flex-1 bg-transparent px-4 py-4 text-sm font-medium focus:outline-none"
            />
            <button 
              onClick={() => {
                if(chatInput.includes('http')) processMaterial(chatInput, 'youtube_url');
                else handleChat();
              }}
              className="w-14 h-14 bg-black text-white rounded-full flex items-center justify-center"
            >
              <Icon name="arrow-up" size={24} />
            </button>
        </div>
      </div>

      {selectedItemId && (
        <div className="fixed inset-0 bg-white z-[60] flex flex-col animate-in slide-in-from-right duration-300">
           <header className="px-6 py-8 flex items-center justify-between border-b border-gray-50 sticky top-0 bg-white/80 backdrop-blur-md">
              <button onClick={() => setSelectedItemId(null)} className="w-12 h-12 flex items-center justify-center bg-gray-50 rounded-2xl">
                <Icon name="chevron-left" size={24} />
              </button>
              <span className="text-[10px] font-black uppercase text-gray-300 tracking-widest tracking-widest">Detail View</span>
              <div className="w-12" />
           </header>
           <div className="flex-1 overflow-y-auto p-8 space-y-10 custom-scrollbar pb-20">
              {(() => {
                const item = media.find(m => m.id === selectedItemId);
                if (!item) return null;
                return (
                  <>
                    <div className="space-y-4">
                      <div className="flex gap-2">
                        <span className="text-[8px] font-black bg-purple-600 text-white px-2 py-1 rounded uppercase">STT: WHISPER</span>
                        <span className="text-[8px] font-black bg-gray-100 text-gray-400 px-2 py-1 rounded uppercase">{item.status}</span>
                      </div>
                      <h1 className="text-4xl font-black leading-none tracking-tighter">{item.title}</h1>
                      <div className="flex gap-2">
                        {item.tags.map(t => <span key={t} className="text-[10px] font-bold text-gray-400">#{t}</span>)}
                      </div>
                    </div>
                    
                    <div className="space-y-3">
                      <h4 className="text-[10px] font-black uppercase tracking-widest text-gray-300">AI Summary</h4>
                      <div className="p-8 bg-gray-50 rounded-[2.5rem] text-base leading-relaxed text-gray-800 font-medium">
                        {item.aiSummary || "Processing..."}
                      </div>
                    </div>

                    <div className="space-y-6">
                      <h4 className="text-[10px] font-black uppercase tracking-widest text-gray-300">Full Transcript</h4>
                      <div className="space-y-6">
                         <p className="text-gray-800 leading-relaxed font-medium whitespace-pre-wrap">{item.rawText || "No content."}</p>
                      </div>
                    </div>
                  </>
                );
              })()}
           </div>
        </div>
      )}
    </div>
  );
};

export default App;
