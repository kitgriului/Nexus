
import { whisperService } from './whisperService';
import { SpeakerTurn, SourceType } from './types';

export const transcriptionService = {
  async processAudio(blob: Blob): Promise<{ text: string, turns: SpeakerTurn[] }> {
    // Шаг 4 "Сценария B": Транскрибация через Whisper
    const text = await whisperService.transcribe(blob);
    
    // Простой парсинг на сегменты (Whisper API возвращает сплошной текст в базовом режиме)
    // Для более детального разбора нужны метки времени, но для MVP используем текст
    const turns: SpeakerTurn[] = [{
      speaker: "Speaker",
      text: text,
      startTime: 0,
      endTime: 0
    }];

    return { text, turns };
  },

  async processUrl(url: string): Promise<{ text: string, title: string }> {
    /**
     * ВНИМАНИЕ: Для работы "Сценария B" с YouTube/Instagram на фронтенде 
     * ТРЕБУЕТСЯ серверный прокси (например, на базе yt-dlp). 
     * Прямой запрос к медиа-потокам YouTube из браузера блокируется политикой CORS.
     */
    console.warn("URL Extraction requires a backend proxy to bypass CORS.");
    
    // Здесь должен быть вызов вашего Backend Extractor Service
    // POST /transcribe/url { url }
    
    throw new Error("Media Extractor (Step 2) requires a Backend Proxy to bypass CORS. Please upload an audio file or use the microphone for now.");
  }
};
