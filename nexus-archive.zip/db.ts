
import { MediaItem, Activity, Subscription, ChatMessage } from './types';

// Простая обертка над IndexedDB для MVP
const DB_NAME = 'NexusVault';
const STORE_NAME = 'media';

const openDB = (): Promise<IDBDatabase> => {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, 3);
    request.onupgradeneeded = (e: any) => {
      const db = e.target.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: 'id' });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
};

export const db = {
  // Media via IndexedDB
  getMedia: async (): Promise<MediaItem[]> => {
    const database = await openDB();
    return new Promise((resolve) => {
      const transaction = database.transaction(STORE_NAME, 'readonly');
      const store = transaction.objectStore(STORE_NAME);
      const request = store.getAll();
      request.onsuccess = () => resolve(request.result.sort((a, b) => b.importedAt - a.importedAt));
    });
  },
  
  saveMediaItem: async (item: MediaItem) => {
    const database = await openDB();
    const transaction = database.transaction(STORE_NAME, 'readwrite');
    const store = transaction.objectStore(STORE_NAME);
    store.put(item);
  },

  deleteMediaItem: async (id: string) => {
    const database = await openDB();
    const transaction = database.transaction(STORE_NAME, 'readwrite');
    const store = transaction.objectStore(STORE_NAME);
    store.delete(id);
  },

  // Metadata via LocalStorage (legacy consistency for small items)
  getActivities: (): Activity[] => JSON.parse(localStorage.getItem('nexus_activities') || '[]'),
  saveActivities: (items: Activity[]) => localStorage.setItem('nexus_activities', JSON.stringify(items)),
  
  getSubscriptions: (): Subscription[] => JSON.parse(localStorage.getItem('nexus_subs') || '[]'),
  saveSubscriptions: (items: Subscription[]) => localStorage.setItem('nexus_subs', JSON.stringify(items)),

  getChatHistory: (): ChatMessage[] => JSON.parse(localStorage.getItem('nexus_chat') || '[]'),
  saveChatHistory: (msgs: ChatMessage[]) => localStorage.setItem('nexus_chat', JSON.stringify(msgs)),

  addActivity: (activity: Omit<Activity, 'id' | 'timestamp'>) => {
    const activities = db.getActivities();
    const newActivity: Activity = { ...activity, id: crypto.randomUUID(), timestamp: Date.now() };
    db.saveActivities([newActivity, ...activities]);
    return newActivity;
  }
};
